const express = require("express");
const app = express();

app.use(express.json());

// Static frontend serve karna
app.use(express.static(__dirname));

// Inventory (products)
let items = [
  { id: 1, name: "Ajrak", price: 1500, origin: "Hala Sindh", rating: 4.5 },
  { id: 2, name: "Sindhi Topi", price: 800, origin: "Sindh", rating: 4.2 }
];

// Middleware
app.use((req, res, next) => {
  console.log(`Customer visited ${req.url} using ${req.method}`);
  next();
});

// GET all items
app.get("/items", (req, res) => {
  res.json(items);
});

// POST item
app.post("/items", (req, res) => {
  const newItem = {
    id: items.length + 1,
    name: req.body.name,
    price: req.body.price,
    origin: req.body.origin,
    rating: req.body.rating || 5
  };

  items.push(newItem);
  res.json({ message: "Item added", item: newItem });
});

// 404 handler
app.use((req, res) => {
  res.status(404).send("404 - Page Not Found");
});

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});