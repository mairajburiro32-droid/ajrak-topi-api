const express = require("express");
const app = express();

app.use(express.json());

// ⭐ IMPORTANT: frontend (HTML files) serve karne ke liye
app.use(express.static(__dirname));


// 📰 News Data (Memory)
let posts = [
  {
    id: 1,
    title: "Welcome to PITP",
    content: "This is our first campus news post",
    author: "Admin"
  },
  {
    id: 2,
    title: "Tech Event",
    content: "AI Seminar will be held next week",
    author: "Ali"
  }
];


// 📢 Logger Middleware
app.use((req, res, next) => {
  console.log(`Request: ${req.method} ${req.url}`);
  next();
});


// ✅ GET ALL POSTS
app.get("/posts", (req, res) => {
  res.json(posts);
});


// ✅ GET SINGLE POST
app.get("/posts/:id", (req, res) => {
  const post = posts.find(p => p.id == req.params.id);

  if (!post) {
    return res.status(404).json({ message: "Post not found" });
  }

  res.json(post);
});


// ➕ CREATE POST
app.post("/posts", (req, res) => {
  const newPost = {
    id: posts.length + 1,
    title: req.body.title,
    content: req.body.content,
    author: req.body.author
  };

  posts.push(newPost);

  res.json({
    message: "Post created successfully",
    post: newPost
  });
});


// ✏️ UPDATE FULL POST (PUT)
app.put("/posts/:id", (req, res) => {
  const post = posts.find(p => p.id == req.params.id);

  if (!post) {
    return res.status(404).json({ message: "Post not found" });
  }

  post.title = req.body.title;
  post.content = req.body.content;
  post.author = req.body.author;

  res.json({
    message: "Post fully updated",
    post
  });
});


// ✏️ PARTIAL UPDATE (PATCH)
app.patch("/posts/:id", (req, res) => {
  const post = posts.find(p => p.id == req.params.id);

  if (!post) {
    return res.status(404).json({ message: "Post not found" });
  }

  if (req.body.title) post.title = req.body.title;
  if (req.body.content) post.content = req.body.content;
  if (req.body.author) post.author = req.body.author;

  res.json({
    message: "Post partially updated",
    post
  });
});


// ❌ DELETE POST
app.delete("/posts/:id", (req, res) => {
  posts = posts.filter(p => p.id != req.params.id);

  res.json({ message: "Post deleted successfully" });
});


// 🚫 404 HANDLER
app.use((req, res) => {
  res.status(404).send("404 - Route Not Found");
});


// 🚀 SERVER START
app.listen(4000, () => {
  console.log("Server running on http://localhost:4000");
});